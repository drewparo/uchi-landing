window.addEventListener( "elementor/init", () => {
	class LiquidBackgroundControlView extends elementor.modules.controls.Base {



	}

	elementor.addControlView( "liquid-background", LiquidBackgroundControlView );
} );
